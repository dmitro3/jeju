exports.handler = async (event) => {
  console.log('Email processor - deploy actual code via CI/CD');
  console.log('Event:', JSON.stringify(event, null, 2));
  return { statusCode: 200 };
};
